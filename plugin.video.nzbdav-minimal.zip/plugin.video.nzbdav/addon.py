import sys
print("hello")
